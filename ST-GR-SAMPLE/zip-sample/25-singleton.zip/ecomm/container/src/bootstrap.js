import 'products/ProductsIndex';
import 'cart/CartShow';

console.log('Container!');
